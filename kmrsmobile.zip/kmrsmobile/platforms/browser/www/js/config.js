var krms_config ={			
	'ApiUrl':"",		
	'DialogDefaultTitle':"KMRS",	
	'pushNotificationSenderid':"",	
	'facebookAppId':"",
	'APIHasKey':""
};

